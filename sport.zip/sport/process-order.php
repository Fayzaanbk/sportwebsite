<?php
require_once "ShoppingCart.php";


require_once "connect.php";
session_start();
$user_id = $_SESSION['user_id']; // to save by id in cart

$shoppingCart = new ShoppingCart();
$cartItem = $shoppingCart->getMemberCartItem($user_id);
$item_quantity = 0;
$item_price = 0;
if (! empty($cartItem)) {
    if (! empty($cartItem)) {
        foreach ($cartItem as $item) {
            $item_quantity = $item_quantity + $item["quantity"];
            $item_price = $item_price + ($item["Price"] * $item["quantity"]);
        }
    }
}
if(!empty($_POST["proceed_payment"])) {
    $name = $_POST ['name'];
    $address = $_POST ['address'];
    $city = $_POST ['city'];
    $email = $_POST ['email'];
    $country = $_POST ['country'];
}
$order = 0;
if (! empty ($name) && ! empty ($address) && ! empty ($city) && ! empty ($email) && ! empty ($country)) {
    // able to insert into database
    
    $order = $shoppingCart->insertOrder ( $_POST, $user_id, $item_price);
    if(!empty($order)) {
        if (! empty($cartItem)) {
            if (! empty($cartItem)) {
                foreach ($cartItem as $item) {
                    $shoppingCart->emptyCart($user_id);
                    $shoppingCart->insertOrderItem ( $order, $item["ID"], $item["Price"], $item["quantity"]);
                }

            }
        }
    }
    
}
?>
<HTML>
<HEAD>
<TITLE>Enriched Responsive Shopping Cart in PHP</TITLE>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel= "stylesheet" href= "style.css">
</HEAD>
<BODY>


<?php
       include("header.php") ;
       ?>
<div class="success">Your Order has been placed Successfully, An agent will contact you shortly.</div>

<div>
    <br>
    <br>
    <h3>Thank you for shopping with us!!   Order number is : <?php echo $order;?></h3>
    <br>
    <br>
    <h4> Enter your order number as reference when using internet banking services.</h4>
    <br>
    <br>
    <button class="btnCart2"><a onclick="location.href = 'product.php';"><i class="fas fa-cart-plus"></i>&nbsp;&nbsp;Continue
                    Shopping</a></button>
    <br>
    <br>
    <button class="btnCart2"><a onclick="location.href = 'accOrder.php';"><i class="fas fa-cart-plus"></i>&nbsp;&nbsp;View Orders</a></button>
    </div>

</BODY>
</HTML>