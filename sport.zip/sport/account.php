<?php

include 'connect.php';
session_start();


/* This is checking if the user is already logged in. If they are, it redirects them to the home page. */
if (isset($_SESSION['name'])) {
    header("Location: accOrder.php");
}



if(isset($_POST['submit'])){

   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = mysqli_real_escape_string($conn, md5($_POST['password']));

   $select = mysqli_query($conn, "SELECT * FROM `user` WHERE email = '$email' AND password = '$pass'") or die('query failed');

   if(mysqli_num_rows($select) > 0){
      $row = mysqli_fetch_assoc($select);
     
      $_SESSION['user_id'] = $row['id'];
      $_SESSION['name'] = $row['name'];
      

      $_SESSION['loggedin'] = true;
      header('location:home.php');
   }else{
      $message[] = 'incorrect password or email!';
   }

}


?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <title>Sportstory</title>
    <link rel="stylesheet" href="style.css">
   <link rel="icon" type="image/x-icon" href="images\favicon.ico.png">
   
   <script src="https://kit.fontawesome.com/6713353c88.js" crossorigin="anonymous"></script>
</head>	
    <body>
    <?php
       include("header.php") ;
       ?>
              <?php

if(isset($message)){
   foreach($message as $message){
      echo '<div class="message" onclick="this.remove();">'.$message.'</div>';
   }
}
?>
	   
             
             
    <!--account page-->
    <div class="account">
		
    <form action="" method="post" class="login-email">
      <p class="login-text">login now</p>
      <div class="input-group">
      <input type="email" name="email" required placeholder="Enter email" class="box">
      </div>
	  <div class="input-group">
      <input type="password" name="password" required placeholder="Enter password" class="box">
      </div>
	  <div class="input-group">
      <input type="submit" name="submit" class="btn" value="login now">
      </div>

      <p class="login-register-text">Don't have an account? <a href="register.php">Register Here</a></p>
      
   </form>





</div>

    </body>
</html>


	
		
