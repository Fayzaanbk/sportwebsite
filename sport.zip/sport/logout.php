/* Destroying the session and redirecting the user to the account page. */
<?php 

session_start();
session_destroy();

header("Location: account.php");

?>