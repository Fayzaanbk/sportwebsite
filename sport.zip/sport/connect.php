<?php
        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbName = "sport1";

	$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);

        // If there is an error with the connection, stop the script and display the error.
        if (!$conn) {
                die("<script>alert('Connection Failed.')</script>");
            }
            
            ?>