<?php
require_once "DBController.php";

class ShoppingCart extends DBController
{
    
    function getAllProduct()
    {
        $query = "SELECT * FROM item WHERE ID>0 && ID<12";
        
        $productResult = $this->getDBResult($query);
        return $productResult;
    }
    function getAllProduct1()
    {
        $query = "SELECT * FROM item WHERE ID > 11  && ID < 23";
        
        $productResult = $this->getDBResult($query);
        return $productResult;
    }
    function getAllProduct2()
    {
        $query = "SELECT * FROM item WHERE ID > 22";
        
        $productResult = $this->getDBResult($query);
        return $productResult;
    }
    function getMale()
    {
        $query = "SELECT * FROM item WHERE genre='M'";
        
        $productResult = $this->getDBResult($query);
        return $productResult;
    }
    function getFemale()
    {
        $query = "SELECT * FROM item WHERE genre='F'";
        
        $productResult = $this->getDBResult($query);
        return $productResult;
    }
    function getKid()
    {
        $query = "SELECT * FROM item WHERE genre='J'";
        
        $productResult = $this->getDBResult($query);
        return $productResult;
    }
    function getAccessories()
    {
        $query = "SELECT * FROM item WHERE genre='A'";
        
        $productResult = $this->getDBResult($query);
        return $productResult;
    }
    function getDetails($id)
    {
        $query = "SELECT * FROM item WHERE ID=?";
        $params = array(
            array(
                "param_type" => "s",
                "param_value" => $id
            )
        );
        
        $productResult = $this->getDBResult($query, $params);
        return $productResult;
    }

    function getMemberCartItem($user_id)
    {
        $query = "SELECT item.*, tbl_cart.id as cart_id,tbl_cart.quantity FROM item, tbl_cart WHERE 
            item.Id = tbl_cart.product_id AND tbl_cart.user_id = ?";
        
        $params = array(
            array(
                "param_type" => "i",
                "param_value" => $user_id
            )
        );
        
        $cartResult = $this->getDBResult($query, $params);
        return $cartResult;
    }

    function getProductByCode($product_code)
    {
        $query = "SELECT * FROM item WHERE product_code=?";
        
        $params = array(
            array(
                "param_type" => "s",
                "param_value" => $product_code
            )
        );
        
        $productResult = $this->getDBResult($query, $params);
        return $productResult;
    }
    

    function getCartItemByProduct($product_id, $user_id)
    {
        $query = "SELECT * FROM tbl_cart WHERE product_id = ? AND user_id = ?";
        
        $params = array(
            array(
                "param_type" => "i",
                "param_value" => $product_id
            ),
            array(
                "param_type" => "i",
                "param_value" => $user_id
            )
        );
        
        $cartResult = $this->getDBResult($query, $params);
        return $cartResult;
    }

    function addToCart($product_id, $quantity,$user_id)
    {
        $query = "INSERT INTO tbl_cart (product_id,quantity,user_id) VALUES (?,?,?)";
        
        $params = array(
            array(
                "param_type" => "i",
                "param_value" => $product_id
            ),
            array(
                "param_type" => "i",
                "param_value" => $quantity
            ),
           
            array(
                "param_type" => "i",
                "param_value" => $user_id
            )
        );
        
        $this->updateDB($query, $params);
    }


    function updateCartQuantity($quantity, $cart_id)
    {
        $query = "UPDATE tbl_cart SET  quantity = ? WHERE id= ?";
        
        $params = array(
            array(
                "param_type" => "i",
                "param_value" => $quantity
            ),
            array(
                "param_type" => "i",
                "param_value" => $cart_id
            )
        );
        
        $this->updateDB($query, $params);
    }

    function deleteCartItem($cart_id)
    {
        $query = "DELETE FROM tbl_cart WHERE id = ?";
        
        $params = array(
            array(
                "param_type" => "i",
                "param_value" => $cart_id
            )
        );
        
        $this->updateDB($query, $params);
    }

    function emptyCart($user_id)
    {
        $query = "DELETE FROM tbl_cart WHERE user_id = ?";
        
        $params = array(
            array(
                "param_type" => "i",
                "param_value" => $user_id
            )
        );
        
        $this->updateDB($query, $params);
    }


      


    function insertOrder($customer_detail, $user_id, $amount)
    {
        $query = "INSERT INTO tbl_order (customer_id, amount, name, address, city, phoneNumber, email, country,payment_type, order_at) VALUES (?, ?, ?, ?, ?, ?,?, ?, ?,?)";
        
        $params = array(
            array(
                "param_type" => "i",
                "param_value" => $user_id
            ),
            array(
                "param_type" => "i",
                "param_value" => $amount
            ),
            array(
                "param_type" => "s",
                "param_value" => $customer_detail["name"]
            ),
            array(
                "param_type" => "s",
                "param_value" => $customer_detail["address"]
            ),
            array(
                "param_type" => "s",
                "param_value" => $customer_detail["city"]
            ),
            array(
                "param_type" => "s",
                "param_value" => $customer_detail["phoneNumber"]
            ),
            array(
                "param_type" => "s",
                "param_value" => $customer_detail["email"]
            ),
            array(
                "param_type" => "s",
                "param_value" => $customer_detail["country"]
            ),
            array(
                "param_type" => "s",
                "param_value" => "paypal"
            ),
         
            array(
                "param_type" => "s",
                "param_value" => date("Y-m-d H:i:s", strtotime("+2 hours"))
            )

        );
        
        $order_id = $this->insertDB($query, $params);
        return $order_id;

        
    }
    
    function insertOrderItem($order, $product_id, $price, $quantity)
    {
        $query = "INSERT INTO tbl_order_item (order_id, product_id, item_price, quantity) VALUES (?, ?, ?, ?)";
        
        $params = array(
            array(
                "param_type" => "i",
                "param_value" => $order
            ),
            array(
                "param_type" => "i",
                "param_value" => $product_id
            ),
            array(
                "param_type" => "i",
                "param_value" => $price
            ),
            array(
                "param_type" => "i",
                "param_value" => $quantity
            )
            );
        
        $this->insertDB($query, $params);
    }
    
}

          ?>