<?php
       include("productAction.php") ;
       session_start();
       $_SESSION['phonenum'];
       ?>
<!DOCTYPE html>
<html>
<head>
    <link rel= "stylesheet" href= "/css/all.min.css">
    <link rel= "stylesheet" href= "style.css">
   <script src="https://kit.fontawesome.com/6713353c88.js" crossorigin="anonymous"></script>
   
</head>	
    <body>      
    <?php
       include("header.php") ;
       ?>
<?php
$cartItem = $shoppingCart->getMemberCartItem($user_id);
$item_quantity = 0;
$item_price = 0;

if (! empty($cartItem)) {
    if (! empty($cartItem)) {
        foreach ($cartItem as $item) {
            $item_quantity = $item_quantity + $item["quantity"];
            $item_price = $item_price + ($item["Price"] * $item["quantity"]);
         
        }
    }
}
?>
              <div class="container4">
    <div class="containerCenter">
      <div class="col-lg-10">
        <div style="display:<?php if (isset($_SESSION['showAlert'])) {
  echo $_SESSION['showAlert'];
} else {
  echo 'none';
} unset($_SESSION['showAlert']); ?>" class="alert alert-success alert-dismissible mt-3">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong><?php if (isset($_SESSION['message'])) {
  echo $_SESSION['message'];
} unset($_SESSION['showAlert']); ?></strong>
        </div>
      
        <div class="small-container cart-page">
        
            <h2>Complete Your Order</h2>
            <div>Total Quantity: <?php echo $item_quantity; ?></div>
            <h4 style="font-weight:normal">Delivery Charge : Free</h4>
                <div><strong>Total Amount Payable: Rs <?php echo $item_price; ?></strong></div>
               
            <br>
           


<?php
$cartItem = $shoppingCart->getMemberCartItem($user_id);
if (! empty($cartItem)) {
    $item_total = 0;
    $totalprice_Item=0;
    ?>	
    
    
<table class="table1" cellspacing="1">
            <tbody>
                <tr>

                    <th style="text-align: left;">Name</th>
                   
                    <th style="text-align: center;">Quantity</th>
                    <th style="text-align: center;">Total Price</th>
                    <th style="text-align: center;">Remove</th>

                </tr>	
<?php
    foreach ($cartItem as $item) {
        ?>
          <?php
         $totalprice_Item=($item["Price"] * $item["quantity"]);
         ?>
				<tr>
                    
                    <td
                        style="text-align: center; border-bottom: #F0F0F0 1px solid;"><?php echo $item["Name"]; ?></td>
     
                    <td
                        style="text-align: center; border-bottom: #F0F0F0 1px solid;"><?php echo $item["quantity"]; ?></td>
                    <td
                        style="text-align: center; border-bottom: #F0F0F0 1px solid;"><?php echo "Rs  ".$totalprice_Item; ?></td>

                    <td
                        style="text-align: center; border-bottom: #F0F0F0 1px solid;"><a
                        href="proceedChk.php?action=remove&id=<?php echo $item["cart_id"]; ?>"
                        class="btnBin" onclick="return confirm('This Item will be remove From your order list, do you want to proceed?');"><i class="fa fa-trash-o" style="font-size:24px"></i></a></td>
                       
                </tr>
				<?php
              
        $item_total += ($item["Price"] * $item["quantity"]);
    }
    ?>
    <?php

if(!empty($_POST["save_order"])) {
    $name = $_POST ['name'];
    $address = $_POST ['address'];
    $city = $_POST ['city'];
    $email = $_POST ['email'];
    $country = $_POST ['country'];
}
$order = 0;
if (! empty ($name) && ! empty ($address) && ! empty ($city) && ! empty ($email) && ! empty ($country)) {
    // able to insert into database
    
    $order = $shoppingCart->insertOrder ( $_POST, $user_id, $item_price);
    if(!empty($order)) {
        if (! empty($cartItem)) {
            if (! empty($cartItem)) {
                foreach ($cartItem as $item) {
                   
                    $shoppingCart->insertOrderItem ( $order, $item["id"], $item["price"], $item["quantity"]);
                
                }
            }
        }
    }
}
?>


            </tbody>
        </table>	
        <br>
       
        <form id="frm_customer_detail" action="process-order.php" method="POST">
    <div class="frm-heading">
        <div class="txt-heading-label">Customer Details</div>
    </div>
    <div class="frm-customer-detail">
        <div class="form-row">
            <div class="input-field">
                <input type="text" value="<?php echo $_SESSION['name']?>"name="name" id="name"
                    PlaceHolder="Customer Name" required>
            </div>

            <div class="input-field">
                <input type="text" name="address" PlaceHolder="Address" required>
            </div>
        </div>

        <div class="form-row">
            <div class="input-field">
                <input type="text" name="city" PlaceHolder="City" required>
            </div>

            <div class="input-field">
                <input type="text"name="phoneNumber" PlaceHolder="Phone Number" required>
            </div>
        </div>

        <div class="form-row">
            <div class="input-field">           
                <input type="email" name="email" PlaceHolder="Email" required>
            </div>

            <div class="input-field">
                <input type="text" name="country" PlaceHolder="Country" required>
            </div>
        </div>
    </div>
    <div>
    
        <input type="submit" class="btn-action" 
                name="proceed_payment" value="Create Order">
    </div>
    </form>

    <br>
    <br>
    <br>

  <?php
}
?>
</div>    
</body>

</html>
