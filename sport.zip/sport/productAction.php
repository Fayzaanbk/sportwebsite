<?php
require_once "ShoppingCart.php";
error_reporting(0);
require_once"connect.php";
session_start();
$user_id = $_SESSION['user_id']; // to save by id in cart

if(isset($_GET['logout'])){
    unset($user_id);
    session_destroy();
    header('location:account.php');
 };



$shoppingCart = new ShoppingCart();
if (! empty($_GET["action"])) {
    switch ($_GET["action"]) {
        
        case "add":
            if(isset($_SESSION['name'])){ 
               
               
                
            if (! empty($_POST["quantity"])) {
                
                $productResult = $shoppingCart->getProductByCode($_GET["code"]);
                
                $cartResult = $shoppingCart->getCartItemByProduct($productResult[0]["ID"], $user_id);
                
                if (! empty($cartResult)) {
                    // Update cart item quantity in database
                    $newQuantity = $cartResult[0]["quantity"] + $_POST["quantity"];
                    
                    $shoppingCart->updateCartQuantity($newQuantity, $cartResult[0]["id"]);
                    $message[] = 'Quantity Updated in Cart !';
                } else {
                    // Add to cart table
               
                    $shoppingCart->addToCart($productResult[0]["ID"], $_POST["quantity"],$user_id);
                    $message[] = 'Item Successfully added to cart!';
                }
            }
        } 
        else{
            header('location:account.php' );
        }
            break;
        case "remove":
            // Delete single entry from the cart
            $shoppingCart->deleteCartItem($_GET["id"]);
           
            break;
        case "empty":
            // Empty cart
            $shoppingCart->emptyCart($user_id);
            break;
    }
}    
// Get no.of items available in the cart table using count row
if (isset($_GET['cartItem']) == 'cart_item') {
  $stmt = $conn->prepare("SELECT quantity FROM tbl_cart where user_id= $user_id");
  $stmt->execute();
  $stmt->store_result();
  $rows = $stmt->num_rows;

  
  echo $rows;
}


      
?>