<?php
require_once "ShoppingCart.php";

$user_id = $_SESSION['user_id'];

$shoppingCart = new ShoppingCart();
 
$shoppingCart->updateCartQuantity($_POST["new_quantity"], $_POST["cart_id"]);
                
?>