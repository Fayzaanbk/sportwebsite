<?php
include 'connect.php';
session_start();
$user_id = $_SESSION['user_id']; 
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <title>Sportstory</title>
    <link rel="stylesheet" href="style.css">
   <link rel="icon" type="image/x-icon" href="images\favicon.ico.png">
   
   <script src="https://kit.fontawesome.com/6713353c88.js" crossorigin="anonymous"></script>
</head>	
    <body>
    <?php
       include("header.php") ;
       ?>
              <?php
if(isset($message)){
   foreach($message as $message){
      echo '<div class="message" onclick="this.remove();">'.$message.'</div>';
   }
}
?>

<br>
<br>
<h2>Account Details </h2>


<?php
$sql="SELECT * FROM user where id=$user_id";
$result=mysqli_query($conn,$sql);
?>

<table class="center1" style="width:50%;margin-left:auto;margin-right:auto;" cellpadding="0" cellspacing="1">

    <tbody>
       
    <?php
while($rows=mysqli_fetch_array($result)){
?>   
        <tr> 
            <th style="text-align: left;"><strong>Username</strong></th>
            <td><?php echo $rows['name']; ?></td>
        </tr> 
        <tr>
            <th style="text-align: left;"><strong>Full Name</strong></th>
            <td><?php echo $rows['fullname']; ?></td>
        </tr>
        <tr>
            <th style="text-align: left;"><strong>Phone Number</strong></th>
            <td><?php echo $rows['phonenum']; ?></td>
        </tr>
        <tr>
            <th style="text-align: left;"><strong>Email address</strong></th>
            <td><?php echo $rows['email']; ?></td>
            <br>
        </tr>
</tbody>
</table>
<br>
<br>
<h2>Order list </h2>
<br>

<?php 
// close while loop 
}
?>

<?php

$query = "SELECT item.Name,item.image,item.ID,tbl_order.customer_id,tbl_order.id,tbl_order.order_at,tbl_order_item.* FROM item,tbl_order,tbl_order_item 
WHERE item.ID=tbl_order_item.product_id AND tbl_order.id=tbl_order_item.order_id AND tbl_order.customer_id=$user_id";
$result1=mysqli_query($conn,$query);
?>

<table class="center1" style="width:50%;margin-left:auto;margin-right:auto;" cellpadding="0" cellspacing="1">

    <tbody>
        
       
        <tr> 
            <th style="text-align: left;"><strong>Date</strong></th>
            <th style="text-align: left;"><strong>Image</strong></th>
            <th style="text-align: left;"><strong>Name</strong></th>
            <th style="text-align: left;"><strong>Order reference</strong></th>
            <th style="text-align: left;"><strong>Unit Price</strong></th>
            <th style="text-align: center;"><strong>Quantity</strong></th>
        </tr> 

        <?php
while($rows=mysqli_fetch_array($result1)){
?>
        <tr>
            <td style="width:100px;">
                <?php echo $rows['order_at']; ?>
            </td>
            
            <td style="width:100px;">
                <img class="image-cart" src="images/<?php echo $rows["image"]; ?>" width=60></div> 
            </td>
            <td style="width:170px;">
                <?php echo $rows['Name']; ?> 
            </td>
            <td style="width:100px;">
                <?php echo $rows['order_id']; ?>
            </td>
            <td style="width:170px;">
                <?php echo $rows['item_price']; ?> 
            </td>
            <td style="width:170px;">
                <?php echo $rows['quantity']; ?> 
            </td>
                    
    </tbody>      

<?php 
// close while loop 
}
?>

</body>
</html>