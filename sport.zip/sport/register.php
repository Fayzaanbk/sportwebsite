<?php 

include 'connect.php';

error_reporting(0);

session_start();
 
 if (isset($_SESSION['username'])) {
     header("Location: home.php");
 }

if (isset($_POST['submit'])) {
	$fullName=$_POST['fullName'];
	$email = $_POST['email'];
	$username = $_POST['username'];
	$phoneNum = $_POST['phoneNum'];
	$password = md5($_POST['password']);
	$cpassword = md5($_POST['cpassword']);

	if ($password == $cpassword) {
		$sql = "SELECT * FROM user WHERE email='$email'";
		$result = mysqli_query($conn, $sql);
		if (!$result->num_rows > 0) {
			$sql = "INSERT INTO user (name, email, password,fullname,phonenum)
					VALUES ('$username', '$email', '$password','$fullName','$phoneNum')";
			$result = mysqli_query($conn, $sql);
			if ($result) {
				echo "<script>alert('User registration successful, Login to continue.')</script>";
				$username = "";
				$email = "";
				$_POST['password'] = "";
				$_POST['cpassword'] = "";
				
			} else {
				echo "<script>alert('Something went wrong')</script>";
			}
		} else {
			echo "<script>alert('The email address alredy exists.Please Login.')</script>";
		}
		
	} else {
		echo "<script>alert('Password Not Matched.')</script>";
	}
}

?>

<!DOCTYPE html>
<html>
<head>
   
<meta charset="UTF-8">
    <title>Sportstory</title>
    <link rel="stylesheet" href="style.css">
   <link rel="icon" type="image/x-icon" href="images\favicon.ico.png">
   <script src="https://kit.fontawesome.com/6713353c88.js" crossorigin="anonymous"></script>
</head>	
    <body>
	<?php
       include("header.php") ;
       ?>

	<div class="account" >

	
		<form action="" method="POST" class="login-email">
	
            <p class="login-text" >Register</p>

			<div class="form-row">
				<div class="input-field1" >
					<input type="text" placeholder="Full name" name="fullName" value="<?php echo $fullName; ?>" required>
				</div>
				<div class="input-field1">
					<input type="email" placeholder="Email" name="email" value="<?php echo $email; ?>" required>
				</div>
			</div>

			<div class="form-row">
				<div class="input-field1" >
					<input type="text" placeholder="Username" name="username" value="<?php echo $username; ?>" required>
				</div>
				<div class="input-field1">
					<input type="text" placeholder="Phone Number" name="phoneNum" value="<?php echo $phoneNum; ?>" required>
				</div>
			</div>

			<div class="form-row">
				<div class="input-field1">
					<input type="password" placeholder="Password" name="password" value="<?php echo $_POST['password']; ?>" required>
            	</div>
            	<div class="input-field1">
					<input type="password" placeholder="Confirm Password" name="cpassword" value="<?php echo $_POST['cpassword']; ?>" required>
				</div>
			</div>

				<div class="input-group">
					<button name="submit" class="btn">Register</button>
				</div>
			<p class="login-register-text">Have an account? <a href="account.php">Login Here</a>.</p>
		</form>

	</div>
</body>
</html>