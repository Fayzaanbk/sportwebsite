<?php
       include("productAction.php") ;
       ?>
<!DOCTYPE html>
<head>
   
    <link rel= "stylesheet" href= "style.css">
   <script src="https://kit.fontawesome.com/6713353c88.js" crossorigin="anonymous"></script>
</head>	
    <body>      
    <?php
       include("header.php") ;
       ?>
   
    
    <?php
    $query = "SELECT * FROM item WHERE ID='id'";
    $product_array = $shoppingCart->getDetails($_GET["id"]);
    if (! empty($product_array)) {
        foreach ($product_array as $key => $value) {
            ?>
               <!--Product detail -->
    <div class="product-detail">
        <div class="backbutton">
    <button class="btnBack" onclick="history.back()">&#8249;</a></button> 
        </div>
    <div class="row-3"> 
        
    <div class="column2">
   
     

    <form method="post" action="cart.php?action=add&code=<?php echo $product_array[$key]["product_code"]; ?>">
              
    <img src="images/<?php echo $product_array[$key]["image"]; ?>">
                
                
            </div>

            <div class="column3">
                <p><?php echo $row["category"]?></p>
                <h1><?php echo $product_array[$key]["Name"]; ?></h1>
                <h4><?php echo "Rs ".$product_array[$key]["Price"]; ?></h4>
                <br>
                <br>
         
                
                <div class="quantity1">
                  <p>Quantity : <input type="number" name="quantity" min="1" step="1"value="1" class="pqty" value="<?= $row['product_qty'] ?>"></p>
                  
                  
                  </div>
                  <br>
                  <br>
                  <button class="btnCart1"> <i class="fas fa-shopping-cart"></i>&nbsp;&nbsp;Add to cart</button>
                  <br>
                  <br>
                  <br>
                  <br>
                <h3>Product Details</h3>
                <br>
                  <br><br>
                  
                <p><?php echo "Rs ".$product_array[$key]["Details"]; ?></p>
                <br>
            </div>

          
            
        </div>
    </div>
      
                <br>
                <br>
                <br>
                <br>
               
               
        </form>
    </div>
    <?php
        }
    }
    ?>
</div>

    
</BODY>
</HTML>