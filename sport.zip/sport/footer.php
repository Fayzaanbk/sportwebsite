 <!--footer-->
 <div class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col-1">
                 <h3>Download Our App</h3>
                 <p style="text-align: Center">Download App for Android and ios mobile phone.</p>
                 <div class="app-Logo">
                    <a href="www.googleplay.com"><img src="images\google.jpg"></a>
                    <a href="www.appstore.com"><img src="images\appstore.jpg"></a>
                 </div>
                </div>
                <div class="footer-col-2">
                 <img src="images/logo.png">
                 <p style="text-align: Center">Our Purpose Is To Sustainably Make the Pleasure and
                 Benefits of Sports Accessible to the Many.</p>
                </div>
                <div class="footer-col-3">
                 <h3>Useful Links</h3>
                 <ul>
                    <li>Coupons</li>
                    <li>Blog Post</li>
                    <li>Return Policy</li>
                    <li>Join Affiliate</li>
                 </ul>
                </div>
                <div class="footer-col-4">
                 <h3>Follow us</h3>
                 <ul>
                    <li><i class="fab fa-facebook"></i> Facebook</li>
                    <li><i class="fab fa-instagram"></i> Instagram</li>
                    <li><i class="fab fa-twitter"></i> Twitter</li>
                    
                 </ul>
                </div>
            </div>
           <hr>
           <p class="copyright"><a href="https://mail.google.com/mail/u/0/#inbox">Umraan & Fayzaan</a>
                Copyright 2022</p>
        </div>
    </div>