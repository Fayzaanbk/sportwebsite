<?php
       include("productAction.php") ;
       ?>
<!DOCTYPE html>
<head>
   
    <link rel= "stylesheet" href= "style.css">
   <script src="https://kit.fontawesome.com/6713353c88.js" crossorigin="anonymous"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
</head>	
    <body>      
    <?php
       include("header.php") ;
       ?>
<?php
if(isset($message)){
   foreach($message as $message){
      echo '<div class="message1" onclick="this.remove();">'.$message.'</div>';
   }
}
?>
<!--All products -->
<div class="container-1">
        <h2 class="title">Our Products</h2>   
                <!--Load from DB-->
        <div class="row-1">

       
    <?php
    $query = "SELECT * FROM item WHERE ID>0 && ID<12 ";
    $product_array = $shoppingCart->getAllProduct($query);
    if (! empty($product_array)) {
        foreach ($product_array as $key => $value) {
            ?>
    <div class="column2">  
 
    
       <form method="post" action="?action=add&code=<?php echo $product_array[$key]["product_code"]; ?>">
 
                <img src="images/<?php echo $product_array[$key]["image"]; ?>">

                <h4><strong><?php echo $product_array[$key]["Name"]; ?></strong></h4>
                <br>
                <p><strong><?php echo "Rs ".$product_array[$key]["Price"]; ?></strong>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<i><a href ="prod-detail.php?id=<?php echo $product_array[$key]["ID"]; ?>" class = "details">View Details</a></i></p>
                <br>
                <br>
                <br>
                <br>
                <div class="quantity">
                  <p>Quantity : </p>
                  <input type="number" name="quantity" min="1" step="1"value="1" class="pqty" value="<?= $row['product_qty'] ?>">
                  
                  </div>
                  
                  <button class="btnCart1"> <i class="fas fa-shopping-cart"></i>&nbsp;&nbsp;Add to cart</button>
               
        </form>
    </div>
    <?php
        }
    }
    ?>
</div>
            
    <!--page button-->
     <div class="page_btn">
        <span>
            <a href="product.php">1</a> 
        </span>    
        <span>
            <a href="product1.php">2</a>
        </span>
        <span>
            <a href="product2.php">3</a>
       </span>
      <span>
      <a href="product1.php">&#8594;</a> 
    </span>
    </div>
    
    <script>
  $(document).ready(function() {

    // Load total no.of items added in the cart and display in the navbar
    load_cart_item_number();

    function load_cart_item_number() {
      $.ajax({
        url: 'productAction.php',
        method: 'get',
        data: {
          cartItem: "cart_item"
        },
        success: function(response) {
          $("#cart-item").html(response);
        }
      });
    }
  });
  </script>
    


    
</BODY>
</HTML>