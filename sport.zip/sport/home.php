<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sportstory</title>
    <link rel="icon" type="image/x-icon" href="images\favicon.ico.png">
    <link rel="Stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
</head>
<body>
          <?php
          include ("header.php");
          ?>
          <br>
          
            <img src="images/menu.jpg" class="menu-icon" onclick=menutoggle()>

            <div class="front-text">
                    <h4>The style our products give!</h4>
                    <br>
                    <p>Our top quality products gives you the style you need for success.</p>
            </div>

            <br>
            <br>

                <!--Front image-->

            <div class = "front-img">
                <div class="front">
                    <a href="categoryMale.php"><img src="images/male.png" style="width:100%"></a>
                </div>
                <div class="front">
                     <a href="categoryFemale.php"><img src="images/female.png" style="width:100%"></a>
                </div>
                <div class="front">
                     <a href="categoryKid.php"><img src="images/kid.png" style="width:100%"></a>
                </div>
                <div class="front">
                     <a href="categoryAccessories.php"><img src="images/other.png" style="width:100%"></a>
                </div>
                <div class = "gif">
                   <a href = "product.php"> <img src="images/shop now.gif" style="width:80%"></a>
                </div>
            </div>      

           
            <!--Slide Show-->
            <br>
            <br>
            <div class="slideshow-container">
                <div class="mySlides fade">
                    <img src="images/puma-banner.jpg" style="width:80%">
                </div>
                <div class="mySlides fade">
                    <img src="images/adidas.jpg" style="width:80%">
                </div>
                <div class="mySlides fade">
                    <img src="images/vans.jpg" style="width:80%">
                </div>
                <div class="mySlides fade">
                    <img src="images/nike.jpg" style="width:80%">
                </div>               
         </div>


                    <div style="text-align:center">
                        <span class="dot"></span> 
                        <span class="dot"></span> 
                        <span class="dot"></span> 
                        <span class="dot"></span> 
                    </div>

                    <script>
                        let slideIndex = 0;
                        showSlides();

                        function showSlides() {
                        let i;
                        let slides = document.getElementsByClassName("mySlides");
                        let dots = document.getElementsByClassName("dot");
                        for (i = 0; i < slides.length; i++) {
                            slides[i].style.display = "none";  
                        }
                        slideIndex++;
                        if (slideIndex > slides.length) {slideIndex = 1}    
                        for (i = 0; i < dots.length; i++) {
                            dots[i].className = dots[i].className.replace(" active", "");
                        }
                        slides[slideIndex-1].style.display = "block";  
                        dots[slideIndex-1].className += " active";
                        setTimeout(showSlides, 2000); // Change image every 2 seconds
                        }
                    </script>

<br>
<br>
<br>


  <!--banner-->
  <div class="banner-container">
    <div class="banner">
        <div class="t-shirt">
            <img src="images/banner1.png">
        </div>
        <div class="content">
            <span>upto</span>
            <h3>50% 0ff</h3>
            <p>offer ending soon</p>
            <a href="product.php" class="btn">view offer</a>
        </div>
        <div class="short">
            <img src="images/banner.png">
        </div>
    </div>
 </div>
  
         
    <!--footer-->
      <?php
        include ("footer.php");
      ?>
    
</body>
</html>