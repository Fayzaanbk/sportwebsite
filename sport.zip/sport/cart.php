<?php
        include("productAction.php") ; 
        session_start();
    ?>

    <!DOCTYPE html>
        <html>
            <head>
            
                <link rel= "stylesheet" href= "style.css">
                <script src="https://kit.fontawesome.com/6713353c88.js" crossorigin="anonymous"></script>
                <script src="jquery-3.2.1.min.js"></script>
                <script>

                    
                    function increment_quantity(cart_id, Price) 
                    {
                   /* Selecting the element with the id "input-quantity-" and the value of the cart_id
                   variable. */
                    var inputQuantityElement = $("#input-quantity-"+cart_id);
                   
                    var newQuantity = parseInt($(inputQuantityElement).val())+1;
                    var newPrice = newQuantity * Price;
                    save_to_db(cart_id, newQuantity, newPrice);
                    }


                    function decrement_quantity(cart_id, Price) 
                    {
                    var inputQuantityElement = $("#input-quantity-"+cart_id);
                        if($(inputQuantityElement).val() > 1) 
                        {
                            var newQuantity = parseInt($(inputQuantityElement).val()) - 1;
                            var newPrice = newQuantity * Price;
                            save_to_db(cart_id, newQuantity, newPrice);
                        }
                    }


                    function save_to_db(cart_id, new_quantity, newPrice) 
                    {
        
                        var inputQuantityElement = $("#input-quantity-"+cart_id);
                        var priceElement = $("#cart-price-"+cart_id);
                        $.ajax({
                        url : "update_cart_quantity.php",
                        data : "cart_id="+cart_id+"&new_quantity="+new_quantity,
                        type : 'post',
                        success : function(response) 
                        {
                            /* Setting the value of the inputQuantityElement to the new_quantity. */
                            $(inputQuantityElement).val(new_quantity);

                            /* Setting the text of the element with the id "cart-price-" and the value
                            of the cart_id variable to the newPrice variable. */
                            $(priceElement).text("Rs"+newPrice);
                            var totalQuantity = 0;
                            
                           /* This is a jQuery selector. It selects all the elements with an id that
                           contains the string "input-quantity-". Then it loops through each of
                           those elements and gets the value of the element. It then adds the value
                           to the totalQuantity variable. */
                            $("input[id*='input-quantity-']").each(function() 
                            {
                                var cart_quantity = $(this).val();
                                totalQuantity = parseInt(totalQuantity) + parseInt(cart_quantity);
                            });
                            $("#total-quantity").text(totalQuantity);
                            var totalItemPrice = 0;
                            $("div[id*='cart-price-']").each(function() 
                            {
                            var cart_price = $(this).text().replace("$","");
                            totalItemPrice = parseInt(totalItemPrice) + parseInt(cart_price);
                            });
                            $("#total-price").text(totalItemPrice);
                            }
                            });
                        }
                </script>
    </head>	
        <body>      
            <?php
                include("header.php") ;
            ?>
    
        <?php
            $cartItem = $shoppingCart->getMemberCartItem($user_id);
           

            if (! empty($cartItem)) 
            {
                $item_quantity = 0;
                $item_price = 0;
                if (! empty($cartItem)) 
                {
                    foreach ($cartItem as $item) 
                    {
                        $item_quantity = $item_quantity + $item["quantity"];
                        $item_price = $item_price + ($item["Price"] * $item["quantity"]);
                    }
                }
            }
        ?>
                
            <div class="container4">
            <div class="containerCenter">
            <div class="col-lg-10">
            <div style="display:
            <?php if (isset($_SESSION['showAlert'])) 
            {
                echo $_SESSION['showAlert'];
            } 
            else 
            {
                echo 'none';
            } 
            unset($_SESSION['showAlert']); ?>" class="alert alert-success alert-dismissible mt-3">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong><?php if (isset($_SESSION['message'])) 
            {
            echo $_SESSION['message'];
            }
            unset($_SESSION['showAlert']); ?></strong>
            </div>
            <div class="small-container cart-page">
                <h2>Products added to cart</h2>
                <div>Total Quantity: <span id="total-quantity"><?php echo $item_quantity; ?></span></div>
                <br>
            
        <?php
            $cartItem = $shoppingCart->getMemberCartItem($user_id);
            if (! empty($cartItem)) 
            {
                $item_total = 0;
                $totalprice_Item=0;
        ?>	
        
            <table class="center" cellpadding="0" cellspacing="1">
                <tbody>
                    <tr>   
                        <th style="text-align: left;"><strong>Image</strong></th>
                        <th style="text-align: left;"><strong>Name</strong></th>
                        <th style="text-align: left;"><strong>Unit Price</strong></th>
                        <th style="text-align: right;"><strong>Quantity</strong></th>
                        <th style="text-align: right;"><strong>Total Price</strong></th>
                        <th style="text-align: center;"><strong>Remove</strong></th>
                        <th><div id="shopping-cart">
                            <div class="txt-heading">
                            <div class="txt-heading-label"></div> 
                            <a class="btnBin" href="cart.php?action=empty"onclick="return confirm('Everything will be removed from your cart, Do you want to proceed?');">
                            <i class="fa fa-trash-o" style="font-size:24px"></i></a>
                            </div>
                        </th>
                    </tr>	
        <?php
            foreach ($cartItem as $item) 
            {
                ?>
                <?php
                $totalprice_Item=($item["Price"] * $item["quantity"]);
                ?>
                <tr>
                    <td ><img class="image-cart" src="images/<?php echo $item["image"]; ?>" width=60></div> </td>   
                        <td style="text-align: left; border-bottom: #F0F0F0 1px solid;"><strong><?php echo $item["Name"]; ?></strong></td>
                        <td style="text-align: center; border-bottom: #F0F0F0 1px solid;"><?php echo "Rs  ".$item["Price"]; ?></td>
                        <td>
                            
                    
                    <div class="btn-increment-decrement" onClick="decrement_quantity(<?php echo $item["cart_id"]; ?>, '<?php echo $item["Price"]; ?>')">-</div>
                    <input class="input-quantity1"
                        id="input-quantity-<?php echo $item["cart_id"]; ?>" value="<?php echo $item["quantity"]; ?>">
                    <div class="btn-increment-decrement"onClick="increment_quantity(<?php echo $item["cart_id"]; ?>, '<?php echo $item["Price"]; ?>')">+</div>
                    </div>
                        </td>
                        <td>
                            <div class="cart-info price" id="cart-price-<?php echo $item["cart_id"]; ?>">
                                <?php echo "Rs ". ($item["Price"] * $item["quantity"]); ?>
                            </div>
                        </td>

                        <td
                            style="text-align: center; border-bottom: #F0F0F0 1px solid;"><a
                            href="cart.php?action=remove&id=<?php echo $item["cart_id"]; ?>"
                            class="btnBin" onclick="return confirm('This Item will be remove permanently from your cart, do you want to proceed?');"><i class="fa fa-trash-o" style="font-size:24px"></i></a></td>

                        </tr>
                    <?php
                    }
                    ?>
                    <tr>
                        <td >
                            <br><button class="btnCart2"><a onclick="history.go(-2)"><i class="fas fa-cart-plus"></i>&nbsp;&nbsp;Continue Shopping</a></button>
                        </td>
                        <td><td> 
                        <td>
                        <br><button class="btnCart2"><a href="proceedChk.php"<?= ($grand_total > 1) ? '' : 'disabled'; ?>><i class="far fa-credit-card"></i>&nbsp;&nbsp;Checkout</a></button>
                        </td>
                    </tr>
                </tbody>
            </table>		
    <?php
    }
    ?>
    </div>  
    </body>
    </html>
