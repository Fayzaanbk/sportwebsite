<?php
error_reporting(0);
session_start();
include("connect.php");

?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>

<div class="logo"> <img src="images/logo2.png" width="150" height="55"></div>
              <div class="navbar">
              <nav>
            <ul>    
            <?php if(isset($_SESSION['name'])){ ?>
                    <li> <?php echo "<p>Welcome " . $_SESSION['name'] . "</p>"; ?></li>
                    <?php} 
                    else{?>
                    
                    <?php
                    }
                    ?>
                    
                    <li> <a href="home.php"><i class="fa fa-fw fa-home"></i> Home</a></li>
                    <li>
                        <a href="product.php"> Product <i class="fas fa-caret-down"></i></a>
                        
                        <div class="dropdown">
                            <ul>
                                <li> <a href="categoryMale.php?id=man"><i class="fas fa-male"></i> Man</a></li>
                                <li> <a href="categoryFemale.php?id=woman"><i class="fas fa-female"></i> Woman</a></li>
                                <li> <a href="categoryKid.php?id=kid"><i class="fas fa-child"></i> Kid</a></li>
                                <li> <a href="categoryAccessories.php?id=accessory">Accessories</a></li>
                            </ul>
                        </div>
                    </li>
                    <li> <a href="contact.php"><i class="fa fa-fw fa-envelope"></i> Contact</a></li>
                    <li> <a href="account.php"><i class="fas fa-user-circle"></i> Account</a></li>
                    <li><a href="cart.php"> <i class="fas fa-shopping-cart"></i></a></li>
                
                   
                    <?php if(isset($_SESSION['name'])){ ?>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i></a></li>
                    <?php} 
                    else{?>
                    
                    <?php
                    }
                    ?>

                  
                    
                    
                  
                </ul>
            </nav>
              </div>
              <script>
  $(document).ready(function() {

    // Load total no.of items added in the cart and display in the navbar
    load_cart_item_number();

    function load_cart_item_number() {
      $.ajax({
        url: 'productAction.php',
        method: 'get',
        data: {
          cartItem: "cart_item"
        },
        success: function(response) {
          $("#cart-item").html(response);
        }
      });
    }
  });
  </script>
             