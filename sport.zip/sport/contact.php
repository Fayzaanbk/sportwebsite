<?php
error_reporting(0);
session_start();
include("connect.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Contact Us</title>
	<link rel= "stylesheet" type="text/css" href= "style.css">
	<script src="https://kit.fontawesome.com/6713353c88.js" crossorigin="anonymous"></script>
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
</head>	
    <body class='contact' background = "images\contact.jpg" style = "  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;">
    <?php
       include("header.php") ;
       ?>
        <div class= "contact-me">
            <h1>Hello Peeps</h1>
            <br>
            <h2>Always at your service!</h2>
        </div>

        
		<div class= "contact-form">
			<form onsubmit = "sendEmail(); reset(); return false;" >
				<input type="text" id="name" class="control-form" placeholder="Your Name" required><br>
		
				<input type="email" id="email" class="control-form" placeholder="Your Email" required ><br>
				
				<textarea id="message" class="control-form" placeholder="How can we help you" rows="4" required></textarea><br>

                <button class="control-form submit"> SEND MESSAGE </button>
				
			</form>
		</div>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://smtpjs.com/v3/smtp.js"></script>

    <script>
        function sendEmail(){
           var name = $('#name').val();
			var email = $('#email').val();
            var message = $('#message').val();

	        //concac the 3 variables
			var Body='Name: '+name+'<br>Email: '+email+'<br>Message: '+message;

            Email.send({
            Host : "smtp.gmail.com",
            Username : "webtect374@gmail.com",
            Password : "web20221",
            To : 'umraangoolfee99@gmail.com', 
            From : document.getElementById("email").value,
            Subject : "New Contact Form Enquiry",
            Body : Body
        }).then(
        message => alert("Message sent successfully !")
        );
        }
     </script>



		<div class="social-icons">
			<ul>
				<li><a href="https://www.facebook.com/"><i class="fab fa-facebook"></i></a></li>
				<li><a href='https://www.instagram.com/?hl=en'><i class="fab fa-instagram"></i></a></li>
				<li><a href="https://twitter.com/"><i class="fab fa-twitter"></i></a></li>
			</ul>
		</div>
    </body>
</html>